<template>
  <div>
    <div>
        <span>{{title}}</span>
    </div>
    <div>

    </div>
    <div v-for="(item,index) in container" :key="index">
      <div>
        <span></span>
      </div>
      <div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>